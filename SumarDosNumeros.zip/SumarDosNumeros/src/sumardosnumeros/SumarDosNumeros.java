package sumardosnumeros;

import javax.swing.JOptionPane;

/**
 *
 * @author simon
 */
public class SumarDosNumeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n1,n2,suma;
        JOptionPane.showMessageDialog(null, "Este programa suma dos numeros :)");
        n1 = Integer.parseInt(JOptionPane.showInputDialog("Digite el primer numero: "));
        n2 = Integer.parseInt(JOptionPane.showInputDialog("Digite el segundo numero: "));
        suma = n1+n2;
        JOptionPane.showMessageDialog(null, "El resultado de la suma es: "+suma);
    }
    
}
